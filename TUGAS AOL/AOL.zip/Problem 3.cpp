#include<stdio.h>

int main(){
	int N;
	
	printf("Ukuran Matriks: ");
	scanf("%d", &N);
	printf("Matriks %dx%d\n", N,N);
	int matriks[N][N];
	int matriks2[N][N];
	int countSize = 0;
	int countSize2 = 0;
	
	printf("Masukkan matriks ke-1: \n");
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			scanf("%d", &matriks[i][j]);
			if (matriks[i][j] == 1){
			countSize++;	
			}
			
		}
	}
	
	printf("Masukkan matriks ke-2: \n");	
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			scanf("%d", &matriks2[i][j]);
			if (matriks2[i][j] == 1){
			countSize2++;	
			}
			
		}
	}
	
	if (countSize > countSize2){
		printf("Object 1 is bigger\n");
	} else if(countSize2 > countSize){
		printf("Object 2 is bigger\n");
	} else {
		printf("Object 1 and 2 has the same size");
	}
	
	
	return 0;
}
