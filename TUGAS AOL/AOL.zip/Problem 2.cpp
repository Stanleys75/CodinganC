#include<stdio.h>
#include<string.h>


struct FriendList{
	char Name[1001];
	char PhoneNumber[14];
	char Address[1001];
};
FriendList data [1001];

int main(){
	int N;
	
	printf("Add Friend Contact\n");
	printf("Number of friends : ");
	scanf("%d", &N); getchar();
	
	for(int i=0;i<N;i++){
		printf("Contact #%d\n", i+1);
		printf("Name         : ");
		scanf("%[^\n]", data[i].Name);	getchar();
	
		printf("Phone Number : ");
		scanf("%[^\n]", data[i].PhoneNumber); getchar();
		
		printf("Address      : ");
		scanf("%[^\n]", data[i].Address); getchar();
		
		printf("\n");
	}
	
	FriendSearch:
	printf("Search friend's name: ");
	
	char search[101];
	scanf("%s", search); getchar();
	
	printf("\nFind Data\n");
	printf("List: \n");
	
	int size = strlen(search);
	bool y = false;
	
	
	for(int i=0;i<N;i++){
		int flag = 0;
		int lenght = strlen(data[i].Name);
		
		for (int j=0;j<lenght;j++){
			int flag2 =0;
			
			for (int k=0;k<size && k+j<lenght;k++){
				if(data[i].Name[j+k] == search[k]){
					flag2++;
				} 
			}
			
			if(flag2 == size){
				flag = 1;
				y = true;
				break;
			} 
		}
		
		if(flag == 1 && y == true){
			printf("%d.%s   %s   %s \n", i+1, data[i].Name, data[i].PhoneNumber, data[i].Address);
		}
		
	}
	
	if( y == false){
		printf("Data Not Exist\n"); 
		goto FriendSearch;
	}
	 
	return 0;
}
